from ro.ubb.movierental.domain.entities import Client
from ro.ubb.movierental.repository.repository import Repository
from _io import open


class ClientRepo(Repository):
    def __init__(self, file_name='client.txt'):
        super().__init__()
        self._file_name = file_name
        self._readFile()

    def add(self, client):
        """
        This function will insert an element into my list.
        """
        super().add(client)
        self._writeToFile()

    def update(self, client):
        """
        This function will update an element with a given id.
        """
        super().update(client)
        self._writeToFile()

    def remove(self, client):
        """
        Will remove a given element from my list.
        """
        super().remove(client)
        self._writeToFile()
        return

    def _writeToFile(self):
        with open(self._file_name, 'w') as f:
            for client in ClientRepo.get_all(self):
                f.write(str(client.get_clientId()) + ',' + client.get_name() + '\n')

    def _readFile(self):
        with open(self._file_name, "r") as f:
            for line in f:
                l = line.split(',')
                l[1] = l[1].split('\n')
                client = Client(int(l[0]), l[1][0])
                ClientRepo.add(self, client)