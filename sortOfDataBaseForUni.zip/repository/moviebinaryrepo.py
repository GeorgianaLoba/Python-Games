from ro.ubb.movierental.domain.entities import Movie
from ro.ubb.movierental.repository.repository import Repository
import pickle


class MovieBinaryRepo(Repository):
    def __init__(self, file_name="movie.pickle"):
        super().__init__()
        self._file_name = file_name
        self._readBinFile()

    def add(self, movie):
        super().add(movie)
        self._writeToBinFile()

    def update(self, movie):
        super().update(movie)
        self._writeToBinFile()

    def remove(self, movie):
        super().remove(movie)
        self._writeToBinFile()
        return

    def _writeToBinFile(self):
        f = open(self._file_name, 'wb')
        pickle.dump(self._elements, f)
        f.close()

    def _readBinFile(self):
        try:
            f = open(self._file_name, "rb")
            self._elements = pickle.load(f)
        except EOFError:
            self._elements = []