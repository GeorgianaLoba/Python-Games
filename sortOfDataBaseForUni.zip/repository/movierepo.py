from ro.ubb.movierental.domain.entities import Movie
from ro.ubb.movierental.repository.repository import Repository
from _io import open


class MovieRepo(Repository):
    def __init__(self, file_name='movie.txt'):
        super().__init__()
        self._file_name = file_name
        self._readFile()

    def add(self, element):
        """
        This function will insert an element into my list.
        """
        super().add(element)
        self._writeToFile()

    def update(self, movie):
        """
        This function will update an element with a given id.
        """
        super().update(movie)
        self._writeToFile()

    def remove(self, movie):
        """
        Will remove a given element from my list.
        """
        super().remove(movie)
        self._writeToFile()
        return

    def _writeToFile(self):
        with open(self._file_name, 'w') as f:
            for movie in MovieRepo.get_all(self):
                f.write(str(movie.get_movieId())+','+ movie.get_title()+',' + movie.get_description() +
                        ',' + movie.get_title()+'\n')

    def _readFile(self):
        with open(self._file_name, "r") as f:
            for line in f:
                l = line.split(',')
                l[3] = l[3].split('\n')
                movie = Movie(int(l[0]), l[1], l[2], l[3][0])
                MovieRepo.add(self, movie)

