import unittest


class IterableDataStruct(object):
    def __init__(self):
        self._lst = []
        self._counter = 0

    def __setitem__(self, index, data):
        self._lst[index] = data

    def __getitem__(self, index):
        return self._lst[index]

    def __delitem__(self, index):
        del self._lst[index]

    def __iter__(self):
        return iter(self._counter)

    def __next__(self):
        try:
            new_lst = self._lst[self._counter]
        except IndexError:
            raise StopIteration()
        self._counter += 1
        return new_lst

    def append(self, value: object):
        self._lst.append(value)

    def load_list(self, lst):
        self._lst = lst[:]


def compare(e1, e2):
    if e1 < e2:
        return True
    return False


def shell_sort(lst, compare):
    # Start with a big gap, then reduce the gap
    n = len(lst)
    gap = int(n / 2)

    # Do a gapped insertion sort for this gap size.
    # The first gap elements a[0..gap-1] are already in gapped
    # order keep adding one more element until the entire array
    # is gap sorted
    while gap > 0:

        for i in range(gap, n):

            # add a[i] to the elements that have been gap sorted
            # save a[i] in temp and make a hole at position i
            temp = lst[i]

            # shift earlier gap-sorted elements up until the correct
            # location for a[i] is found
            j = i
            while j >= gap and compare(lst[j - gap], temp) is True:
                lst[j] = lst[j - gap]
                j -= gap

                # put temp (the original a[i]) in its correct location
            lst[j] = temp
        gap //= 2
    return lst

def acceptance(elem, lst):
    for i in lst:
        if i == elem:
            return True
    return False

def filter_fct(lst, acceptance):
    new_lst = []
    for element in lst:
        if acceptance(element) is True:
            new_lst.append(element)
    return new_lst


class TestIterableDataStruct(unittest.TestCase):
    def setUp(self):
        self.__lst = [22, -15, 2, 9, -2, 44, 3]
        self.__counter = 0

    def test_shell_sort(self):
        new_lst = shell_sort(self.__lst, lambda x, y: x > y)
        self.assertEqual(new_lst[0], -15)
        self.assertEqual(new_lst[1], -2)
        self.assertEqual(new_lst[2], 2)
        self.assertNotEqual(new_lst[3], 9)
        self.assertEqual(new_lst[6], 44)
        new_lst = shell_sort(self.__lst, lambda x, y: x < y)
        self.assertEqual(new_lst[0], 44)
        self.assertEqual(new_lst[6], -15)

    def test_filter_fct(self):
        filt_list = [2, -2, 44]
        new_lst = filter_fct(self.__lst, lambda x: x in filt_list)
        self.assertEqual(len(new_lst), 3)
        new_lst = filter_fct(self.__lst, lambda x: x not in filt_list)
        self.assertEqual(len(new_lst), 4)
        filt_list = []
        new_lst = filter_fct(self.__lst, lambda x: x in filt_list)
        self.assertEqual(len(new_lst), 0)