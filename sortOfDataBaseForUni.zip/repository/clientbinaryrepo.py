import pickle

from ro.ubb.movierental.domain.entities import Client
from ro.ubb.movierental.repository.repository import Repository
from _io import open


class ClientBinaryRepo(Repository):
    def __init__(self, file_name='client.pickle'):
        super().__init__()
        self._file_name = file_name
        self._readBinFile()

    def add(self, client):
        super().add(client)
        self._writeToBinFile()

    def update(self, client):
        super().update(client)
        self._writeToBinFile()

    def remove(self, client):
        super().remove(client)
        self._writeToBinFile()
        return

    def _writeToBinFile(self):
        f = open(self._file_name, 'wb')
        pickle.dump(self._elements, f)
        f.close()

    def _readBinFile(self):
        try:
            f = open(self._file_name, 'rb')
            self._elements = pickle.load(f)
        except EOFError:
            self._elements = []