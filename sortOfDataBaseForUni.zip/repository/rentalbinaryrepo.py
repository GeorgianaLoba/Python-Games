import pickle
from ro.ubb.movierental.domain.entities import Rental
from ro.ubb.movierental.errors.errors import RepositoryError
from ro.ubb.movierental.repository.repository import Repository
from _io import open


class RentalBinaryRepo(Repository):
    def __init__(self, file_name='rental.pickle'):
        super().__init__()
        self._file_name = file_name
        self._readBinFile()

    def add(self, rental):
        super().add(rental)
        self._writeToBinFile()

    def update(self, rental):
        super().update(rental)
        self._writeToBinFile()

    def remove(self, rental):
        super().remove(rental)
        self._writeToBinFile()
        return

    def _writeToBinFile(self):
        f = open(self._file_name, 'wb')
        pickle.dump(self._elements, f)
        f.close()

    def _readBinFile(self):
        try:
            f = open(self._file_name, "rb")
            self._elements = pickle.load(f)
        except EOFError:
            self._elements = []