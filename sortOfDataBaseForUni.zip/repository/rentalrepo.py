from ro.ubb.movierental.domain.entities import Rental
from ro.ubb.movierental.errors.errors import RepositoryError
from ro.ubb.movierental.repository.repository import Repository
from _io import open


class RentalRepo(Repository):
    def __init__(self, file_name='rental.txt'):
        super().__init__()
        self._file_name = file_name
        self._readFile()

    def add(self, rental):
        """
        This function will insert an element into my list.
        """
        super().add(rental)
        self._writeToFile()


    def update(self, rental):
        """
        This function will update an element with a given id.
        """
        super().update(rental)
        self._writeToFile()


    def remove(self, rental):
        """
        Will remove a given element from my list.
        """
        super().remove(rental)
        self._writeToFile()
        return

    def _writeToFile(self):
        with open(self._file_name, 'w') as f:
            for rental in RentalRepo.get_all(self):
                if rental.get_returnedDate() is not None:
                    x = str(rental.get_returnedDate())
                else:
                    x = 'None'
                f.write(str(rental.get_rentalId())+',' + str(rental.get_movieId()) + ',' + str(rental.get_clientId()) +
                        ',' + str(rental.get_rentedDate())+',' + str(rental.get_dueDate())+',' +
                        x + '\n')

    def _readFile(self):
        with open(self._file_name, "r") as f:
            for line in f:
                l = line.split(',')
                l[5]=l[5].split('\n')
                rental = Rental(int(l[0]), l[1], l[2], l[3], l[4], l[5][0])
                RentalRepo.add(self, rental)