import random
from sqlite3.dbapi2 import Date
from datetime import datetime
from ro.ubb.movierental.errors.errors import ValidationError, RepositoryError
from ro.ubb.movierental.service.redo.manager import RedoManager
from ro.ubb.movierental.service.undo.handlers import UndoHandler
from ro.ubb.movierental.service.undo.manager import UndoManager


class Console:
    def __init__(self, __movie_service, __client_service, __rental_service):
        self.__movie_service = __movie_service
        self.__client_service = __client_service
        self.__rental_service = __rental_service


# ____________________________________movies___________________________________________

    def __add_movies(self):
        number_of_movies = 30
        self.__movie_service.add_movie(12, 'The Elephant Man', 'extremely touching', 'drama')
        self.__movie_service.add_movie(18, 'Silence of the lambs', 'nerve-wrecking', 'psychological')
        self.__movie_service.add_movie(19, 'The Saw', 'interesting idea', 'horror')
        self.__movie_service.add_movie(22, 'The remains of a day', 'about unrequited love', 'drama')
        self.__movie_service.add_movie(27, 'The lord of the rings', 'exciting imagery', 'fantasy')
        self.__movie_service.add_movie(33, 'Gone with the wind', 'entertaining', 'romance')

        title1 = ["Strange", "Misery", "Chaos", "Flower", "Adventure", "Red", "Story", "Mary", "Simpleton", "Forest",
                  "Mountains", "River", "House", "Marceline", "The", "Song", "Rainy", "Hell", "Dogs", "Black", "Little",
                  "Saturday", "Lost", "Noble", "News", "Hunter", "Precious"]
        title2 = ["Margaret", "Blues", "Park", "Music", "Danger", "Lover", "Dinner", "Books", "Road", "Mary", "Nabla",
                  "War", "Returns", "Act",  "Boy", "Women", "Office"]
        description = ["Surprising", "Exciting imagery", "Adventurous", "Funny", "Chaotic", "Scary", "Breath-taking",
                       "Entertaining", "Lacking in plot", "Boring", "Interesting", "Extremely Touching",
                       "Full of ideas", "Only children will find this interesting", "Soap-opera", "never-again",
                       "worth all your money"]
        genre = ["drama", "romance", "horror", "comedy", "action", "adventure", "thriller", "western", "animation",
                 "science-fiction", "musical", "fantasy", "documentary"]

        for n in range(0, number_of_movies):
            t = random.choice(title1)+" "+random.choice(title2)
            d = random.choice(description)
            g = random.choice(genre)
            self.__movie_service.add_movie(35+n, t, d, g)

    def __ui_add_movie(self):
        try:
            movieId = int(input("Movie id: "))
        except:
            raise ValueError ("There should be an int.")
        title = input("Movie title: ")
        description = input("Movie description: ")
        genre = input ("Movie genre: ")
        self.__movie_service.add_movie(movieId, title, description, genre)

    def __ui_print_movies(self):
        movies = self.__movie_service.get_all_movies()
        if len(movies) == 0:
            print("There are no movies to print.")
            return
        s = ""
        for movie in movies:
            s += str(movie) + "\n"
        print(s)

    def __ui_remove_movie(self):
        try:
            id = int(input("Enter the id of the movie you want to remove: "))
        except:
            raise ValueError ("There should be an int.")
        movies = self.__movie_service.get_all_movies()
        m = self.__movie_service.get_by_id(id)
        for movie in movies:
            if movie == m:
                list1 = self.__movie_service.remove_movie(movie)
                list2 = self.__rental_service.remove_rental_by_movie(movie)
                UndoManager.register_operation(self.__movie_service, UndoHandler.REMOVE_MOVIE, list1[0], list1[1],
                                               list1[2], list1[3], list2, self.__rental_service)

    def __ui_update_movie(self):
        try:
            id = int(input("Enter a movie id: "))
        except ValueError:
            print("The id needs to be an int.")
        title = input("Title: ")
        description = input("Description: ")
        genre = input("Genre: ")
        movie = self.__movie_service.create_movie(id, title, description, genre)
        self.__movie_service.update_movie(movie)

    def __ui_search_movies(self):
        key = input("Enter a key for searching: ")
        try:
            int(key)
            print(str(self.__movie_service.get_by_id(key)))
        except:
            movies = list(self.__movie_service.search_movies_by_word(key))
            if len(movies) == 0:
                print("There are no movies with that word.")
            output = ""
            for movie in movies:
                output += str(movie) + "\n"
            print(output)

# __________________________________clients______________________________________

    def __add_clients(self):
        self.__client_service.add_client(1, 'Marco McWitz')
        self.__client_service.add_client(2, 'Antonia Maria Florenco')
        self.__client_service.add_client(3, 'Celine Mia Summarr')
        self.__client_service.add_client(4, 'Gregory Schmitz')
        self.__client_service.add_client(5, 'Maria Varga')
        self.__client_service.add_client(6, 'Tom Ford')

        number_of_people = 30

        name1 = ["Maria", "Anton", "Geo", "Luca", "Ioana", "Mark", "Eveline", "Eve", "Ana", "Ana-Maria", "Maria", "Tom",
                 "Andrei", "Alex", "Alexandra", "John", "Mihai", "Stefan", "Razvan", "George-Andrei", "Tomas"]
        name2 = ["Brian", "Marco", "Smith", "Smiths", "Johnson", "Marcov", "Sarmvo", "D'Anton", "Ioorp", "Di Garo",
                "Nemo", "Svillian", "Florenciago", "Barbads", "Snaiw", "Mircle"]

        for n in range (0, number_of_people):
            name = random.choice(name1) + " " + random.choice(name2)
            self.__client_service.add_client(7+n, name)

    def __ui_add_client(self):
        try:
            clientId = int(input("Client id: "))
        except:
            raise ValueError("There should be an int.")
        name = input("Client name: ")
        self.__client_service.add_client(clientId, name)

    def __ui_print_clients(self):
        clients = self.__client_service.get_all_clients()
        if len(clients) == 0:
            print("There are no clients to print.")
            return
        s = ""
        for client in clients:
            s += str(client) + "\n"
        print(s)

    def __ui_remove_client(self):
        try:
            id = int(input("Enter the id of the client you want to remove: "))
        except:
            raise ValueError ("There should be an int.")
        clients = self.__client_service.get_all_clients()
        c = self.__client_service.get_by_id(id)
        for client in clients:
            if client == c:
                list1 = self.__client_service.remove_client(client)
                list2 = self.__rental_service.remove_rental_by_client(client)
                UndoManager.register_operation(self.__client_service, UndoHandler.REMOVE_CLIENT, list1[0], list1[1],
                                               list2, self.__rental_service)

    def __ui_update_client(self):
        try:
            id = int(input("Enter a client id: "))
        except:
            raise ValueError ("The id needs to be an int.")
        name = input("Enter a client name: ")
        client = self.__client_service.create_client(id, name)
        self.__client_service.update_client(client)

    def __ui_search_clients(self):
        key = input("Enter a key for searching: ")
        try:
            int(key)
            print(str(self.__client_service.get_by_id(key)))
        except:
            clients = list(self.__client_service.search_clients_by_word(key))
            if len(clients) == 0:
                print("There are no clients with that word.")
            output = ""
            for client in clients:
                output += str(client) + "\n"
            print(output)

    # _________________________________rentals__________________________________

    def __add_rentals(self):
        number_of_rentals = 30

        self.__rental_service.add_rental(1, 22, 3, Date(2018, 10, 25), Date(2018, 11, 25), Date(2018, 11, 13))
        self.__rental_service.add_rental(2, 27, 2, Date(2018, 11, 20), Date(2018, 12, 20))
        self.__rental_service.add_rental(3, 18, 3, Date(2018, 11, 4), Date(2018, 12, 4), Date(2018, 12, 1))
        self.__rental_service.add_rental(4, 12, 5, Date(2018, 11, 22), Date(2018, 12, 22))
        self.__rental_service.add_rental(5, 22, 2, Date(2018, 11, 17), Date(2018, 12, 17))
        self.__rental_service.add_rental(6, 18, 1, Date(2018, 11, 14), Date(2018, 12, 14))
        self.__rental_service.add_rental(7, 19, 1, Date(2018, 10, 19), Date(2018, 11, 19))

        year = [2016, 2017, 2018]
        for n in range(0, number_of_rentals):
            d = random.randint(1, 28)
            m = random.randint(1, 11)
            y = random.choice(year)
            self.__rental_service.add_rental(8+n, random.randint(35, 60), random.randint(8, 35),
                                             Date(y, m, d),
                                             Date(y, m+1, d),
                                             Date(y, random.randint(m, 12), random.randint(1, 28)))
    def __ui_remove_rental(self):
        try:
            id = int(input("Insert the id of the rental you want to remove: "))
        except:
            raise ValueError ("The id needs to be an int.")
        r = self.__rental_service.get_by_id(id)
        rentals = self.__rental_service.get_all_rentals()
        for rental in rentals:
            if rental == r:
                self.__rental_service.remove_rental(r)

    def __ui_print_rentals(self):
        rentals = self.__rental_service.get_all_rentals()
        if len(rentals) == 0:
            print("There are no rentals to print.")
            return
        s = ""
        for rental in rentals:
            s += str(rental) + "\n"
        print(s)

    def __ui_rent_movie(self):
        rentalId = int(input("Rental Id: "))
        movieId = int(input("Movie Id: "))
        clientId = int(input("Client Id: "))
        d = datetime.now().day
        m = datetime.now().month
        y = datetime.now().year
        rentedDate = Date(y, m, d)
        if m < 12:
            dueDate = Date(y, m + 1, d)
        else:
            dueDate = Date(y + 1, 1, d)
        self.__rental_service.add_rental(rentalId, movieId, clientId, rentedDate, dueDate)

    def __ui_return_movie(self):
        try:
            rentalId = int(input("Insert the id of the rental you want to return: "))
        except:
            raise ValueError ("The id needs to be an int.")
        d = datetime.now().day
        m = datetime.now().month
        y = datetime.now().year
        returnedDate = Date(y, m, d)
        self.__rental_service.return_movie(rentalId, returnedDate)

    def __ui_most_rented_movies(self):
        dtos = list(self.__rental_service.most_rented_movies())
        if len(dtos) == 0:
            print("There are no movies rented.")
        output = ""
        for dto in dtos:
            output += str(dto) + "\n"
        print(output)

    def __ui_most_active_clients(self):
        dtos = list(self.__rental_service.most_active_clients())
        if len(dtos) == 0:
            print("There are no active clients.")
        output = ""
        for dto in dtos:
            output += str(dto) + "\n"
        print(output)

    def __ui_all_movies_currently_rented(self):
        movies = list(self.__rental_service.movies_currently_rented())
        if len(movies)== 0:
            print("There are no movies currently rented.")
        for movie in movies:
            print(movie.get_title())

    def __ui_late_movie_rentals(self):
        dtos = list(self.__rental_service.late_rentals())
        if len(dtos) == 0:
            print("There are no late rentals.")
        output = ""
        for dto in dtos:
            output += str(dto) + "\n"
        print(output)

    def __undo(self):
        UndoManager.undo()

    def __redo(self):
        RedoManager.redo()

    def __display(self):
        print("Ciao!\n"
              "Press 1 in order to add a movie.\n",
              "Press 2 in order to add a client.\n",
              "Press 3 in order to remove a movie.\n",
              "Press 4 in order to remove a client.\n",
              "Press 5 in order to remove a rental.\n",
              "Press 6 in order to update a movie.\n",
              "Press 7 in order to update a client.\n",
              "Press 8 in order to print all movies.\n",
              "Press 9 in order to print all clients.\n",
              "Press 10 in order to print all rentals.\n",
              "Press 11 in order to print everything.\n",
              "Press 12 in order to rent a movie.\n",
              "Press 13 in order to return a movie.\n",
              "Press 14 in order to search a movie.\n",
              "Press 15 in order to search a client.\n",
              "Press 16 in order to get most rented movies (in descending order).\n",
              "Press 17 in order to get most active clients.\n",
              "Press 18 in order to get the titles of the movies that are currently rented.\n",
              "Press 19 in order to get the late rentals\n",
              "Press 20 in order to undo.\n",
              "Press 21 in order to redo.\n",
              "Press 0 for exit.\n")

    def generate_in_memory(self):
        self.__add_clients()
        self.__add_movies()
        self.__add_rentals()

    def run(self):
        self.__display()
        while True:
            try:
                try:
                    choice = int(input("Enter your choice: "))
                except:
                    raise ValueError("Here should be an int.")
                if choice == 0:
                    print('cya')
                    break
                if choice == 1:
                    self.__ui_add_movie()
                if choice == 2:
                    self.__ui_add_client()
                if choice == 3:
                    self.__ui_remove_movie()
                if choice == 4:
                    self.__ui_remove_client()
                if choice == 5:
                    self.__ui_remove_rental()
                if choice == 6:
                    self.__ui_update_movie()
                if choice == 7:
                    self.__ui_update_client()
                if choice == 8:
                    self.__ui_print_movies()
                if choice == 9:
                    self.__ui_print_clients()
                if choice == 10:
                    self.__ui_print_rentals()
                if choice == 11:
                    self.__ui_print_movies()
                    self.__ui_print_clients()
                    self.__ui_print_rentals()
                if choice == 12:
                    self.__ui_rent_movie()
                if choice == 13:
                    self.__ui_return_movie()
                if choice == 14:
                    self.__ui_search_movies()
                if choice == 15:
                    self.__ui_search_clients()
                if choice == 16:
                    self.__ui_most_rented_movies()
                if choice == 17:
                    self.__ui_most_active_clients()
                if choice == 18:
                    self.__ui_all_movies_currently_rented()
                if choice == 19:
                    self.__ui_late_movie_rentals()
                if choice == 20:
                    self.__undo()
                if choice == 21:
                    self.__redo()
            #except ValueError as ve:
            #    print("Value Error: ", ve)
            #except ValidationError as vve:
            #    print("Validation Error: ", vve)
            #except RepositoryError as re:
            #    print("Repo Error: ", re)
            #except Exception as ex:
            #   print("Unknown exception: ", ex)
            except:
                pass


