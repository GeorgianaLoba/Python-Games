from enum import Enum


def remove_movie_redo_handler(movie_service, movieId, title, description, genre):
    movie_service.add_movie(movieId, title, description, genre)


def remove_client_redo_handler(client_service, clientId, name):
    client_service.add_client(clientId, name)


def remove_rental_redo_handler(rental_service, rentalId, movieId, clientId, rentedDate, dueDate, returnedDate):
    rental_service.add_rental(rentalId, movieId, clientId, rentedDate, dueDate, returnedDate)


def add_movie_redo_handler(movie_service, movieId, title, description, genre, list, rental_service):
    movie_service.remove_movie(movie_service.create_movie(movieId, title, description, genre))
    for rental in list:
        rental_service.remove_rental(rental_service.create_rental(rental.get_rentalId(), rental.get_movieId(), rental.get_clientId(),
                                     rental.get_rentalId, rental.get_dueDate(), rental.get_returnedDate()))


def add_client_redo_handler(client_service, clientId, name, list, rental_service):
    client_service.remove_client(client_service.create_client(clientId, name))
    for rental in list:
        rental_service.remove_rental(
            rental_service.create_rental(rental.get_rentalId(), rental.get_movieId(), rental.get_clientId(),
                                         rental.get_rentalId, rental.get_dueDate(), rental.get_returnedDate()))


def add_rental_redo_handler(rental_service, rentalId, movieId, clientId, rentedDate, dueDate, returnedDate):
    rental_service.remove_rental(rental_service.create_rental(rentalId, movieId, clientId, rentedDate, dueDate, returnedDate))


def update_movie_redo_handler(movie_service, movieId, title, description, genre):
    movies = movie_service.get_all_movies()
    for movie in movies:
        if movie.get_movieId() == int(movieId):
            movie.set_title(title)
            movie.set_description(description)
            movie.set_genre(genre)
            break


def update_client_redo_handler(client_service, clientId, name):
    clients = client_service.get_all_clients()
    for client in clients:
        if client.get_clientId() == int(clientId):
            client.set_name(name)
            break


class RedoHandler(Enum):
    REMOVE_MOVIE = remove_movie_redo_handler
    REMOVE_CLIENT = remove_client_redo_handler
    REMOVE_RENTAL = remove_rental_redo_handler
    ADD_MOVIE = add_movie_redo_handler
    ADD_CLIENT = add_client_redo_handler
    ADD_RENTAL = add_rental_redo_handler
    UPDATE_MOVIE = update_movie_redo_handler
    UPDATE_CLIENT = update_client_redo_handler
