"""
Everything in the redo manager and and redo handlers modules are using the same logic as in undo manager and undo
handlers, but reversed.
"""

class RedoOperations:
    def __init__(self, source_obj, handler, args):
        self.__source_obj = source_obj
        self.__handler = handler
        self.__args = args

    def get_source_obj(self):
        return self.__source_obj

    def get_handler(self):
        return self.__handler

    def get_args(self):
        return self.__args

    def __str__(self) -> str:
        return "The {0} has {1} with {2}".format(self.get_source_obj(), self.get_handler(), self.get_args())

class RedoManager:
    __redo_operations = []

    @staticmethod
    def register_operation(source_obj, handler, *args):
        RedoManager.__redo_operations.append(RedoOperations(source_obj, handler, args))

    @staticmethod
    def redo():
        if len(RedoManager.__redo_operations) == 0:
            raise ValueError("Nothing to redo anymore.")
        redo_operation = RedoManager.__redo_operations.pop()
        redo_operation.get_handler()(redo_operation.get_source_obj(), *redo_operation.get_args())

