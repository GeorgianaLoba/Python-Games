import operator
from sqlite3.dbapi2 import Date
from datetime import datetime

from ro.ubb.movierental.domain.dto import MovieDto, ClientDto
from ro.ubb.movierental.domain.entities import Rental
from ro.ubb.movierental.repository.iterabledata import shell_sort, filter_fct
from ro.ubb.movierental.service.undo.handlers import UndoHandler
from ro.ubb.movierental.service.undo.manager import UndoManager


class RentalService:
    def __init__(self, __repo, __movie_service, __client_service, __valid):
        self.__repo = __repo
        self.__movie_service = __movie_service
        self.__client_service = __client_service
        self.__valid = __valid

    def create_rental(self, rentalId, movieId, clientId, rentedDate, dueDate, returnedDate=None):
        """
        Will create a rental object and then return it
        """
        rental = Rental(rentalId, movieId, clientId, rentedDate, dueDate, returnedDate)
        self.__valid.validate_rental(rental)
        return rental

    def remove_rental(self, rental):
        self.__repo.remove(rental)
        UndoManager.register_operation(self, UndoHandler.REMOVE_RENTAL, rental.get_rentalId(), rental.get_movieId(),
                                       rental.get_clientId(), rental.get_rentedDate(), rental.get_dueDate(),
                                       rental.get_returnedDate())

    def remove_rental_by_client(self, client):
        """
        If a client is removed from the database, all his/hers corresponding rentals will be removed as well.
        This function will remove all rentals of a certain client.
        """
        undo_list = []
        rentals = self.get_all_rentals()
        for rental in rentals:
            if client.get_clientId() == rental.get_clientId():
                self.__repo.remove(rental)
                undo_list.append(rental)
        return undo_list

    def remove_rental_by_movie(self, movie):
        """
        This function will remove all rentals of a certain movie.
        """
        undo_list = []
        rentals = self.get_all_rentals()
        for rental in rentals:
            if movie.get_movieId() == rental.get_movieId():
                self.__repo.remove(rental)
                undo_list.append(rental)
        return undo_list

    def get_all_rentals(self):
        return self.__repo.get_all()

    def update_rental(self, rental):
        self.__repo.update(rental)

    def get_by_id(self, id):
        """
        This function will search in the list of rentals the rental with the given id(if it exists)
        """
        rentals = self.get_all_rentals()
        for rental in rentals:
            if rental.get_rentalId() == int(id):
                return rental

    def add_rental(self, rentalId, movieId, clientId, rentedDate, dueDate, returnedDate=None):
        """
        This function is adding a rental to my list of rentals. Before doing it, it checks if the rental is elligible,
        meaning: the movie is not already rented and the client doesn't have a movie that passed its return date.
        """
        correct = 0
        movies = self.__movie_service.get_all_movies()
        # checks if there exists a movie/client with the ids given as parameters
        for movie in movies:
            if movie.get_movieId() == int(movieId):
                clients = self.__client_service.get_all_clients()
                for client in clients:
                    if client.get_clientId() == int(clientId):
                        correct = 1
        if correct == 0:
            raise ValueError("There is no client or no movie with that id. Try again.")
        # checks the validity of a movie/client
        rentals = self.get_all_rentals()
        for rental in rentals:
            if rental.get_movieId() == int(movieId) and rental.get_returnedDate() is None:
                raise ValueError("This movie is already rented.")
            if rental.get_clientId() == int(clientId) and rental.get_returnedDate() is None:
                d = datetime.now().day
                m = datetime.now().month
                y = datetime.now().year
                today = Date(y, m, d)
                if today > rental.get_dueDate():
                    raise ValueError("This client need to return a movie first.")
        # if every condition is checked, the function creates an object rental and inserts it into my list of rentals
        self.__repo.add(self.create_rental(rentalId, movieId, clientId, rentedDate, dueDate, returnedDate))
        UndoManager.register_operation(self, UndoHandler.ADD_RENTAL, rentalId, movieId, clientId, rentedDate, dueDate, returnedDate)

    def return_movie(self, rentalId, returnedDate):
        """
        this function is updating my rental object by inserting a returned date to a certain rental
        """
        rentals = self.get_all_rentals()
        for rental in rentals:
            if rental.get_rentalId() == int(rentalId):
                r = self.create_rental(rental.get_rentalId(), rental.get_movieId(), rental.get_clientId(),
                                       rental.get_rentedDate(), rental.get_dueDate(), returnedDate)
                self.update_rental(r)
                return
        raise ValueError("There is no rental with that id.")

    def __get_movies_dtos(self):
        """
        This function is returning a list of dtos, containing the movie title and how many times it has been rented.
        First, we will create a dict that will have the movie ids as keys and how many times the movie has been rented
        as values. Further, we will create the list of dtos.
        """

        movies = self.__movie_service.get_all_movies()
        rentals = self.get_all_rentals()
        # creates a dictionary that has an unique key(movie ID) and as values, the number of times
        # that movie was rented
        new_dict = {}
        for movie in movies:
            new_dict[movie.get_movieId()] = 0  # we initialize the values of the dict to 0
        for rental in rentals:
            id = rental.get_movieId()
            for movie in movies:
                if movie.get_movieId() == int(id):
                    new_dict[movie.get_movieId()] += 1  # we count how many times a movie was rented
        dtos = []
        for key, value in new_dict.items():
            movie = self.__movie_service.get_by_id(key)
            movie_dto = MovieDto(movie.get_title(), value)
            dtos.append(movie_dto)
        return dtos

    def most_rented_movies(self):
        """
        This will return a list of dto objects that contain only the movie title and how many times each movie was
        rented in a descending order (the most rented movie first).
        """
        dtos = self.__get_movies_dtos()
        # return sorted(dtos, reverse=True,  key=operator.attrgetter('count'))
        return shell_sort(dtos, lambda x, y: x.get_count() < y.get_count())

    def movies_currently_rented(self):
        """
        This functions returns a list of movies that are currently rented.
        """
        movies = self.__movie_service.get_all_movies()
        rentals = self.get_all_rentals()
        """
        new_list = []
        for rental in rentals:
            id = rental.get_movieId()
            for movie in movies:
                if movie.get_movieId() == int(id):
                    if movie not in new_list:  # checks for dublicates
                        new_list.append(movie)
        return new_list
        """
        new_list = filter_fct(movies, lambda x: x in rentals)
        return new_list

    def __get_clients_dto(self):
        """
        This function will return a list of dtos, containing the name of the client and how many rental days each one of
        them has. First, we create a dict that has client ids as keys and the rental days as values and after that we
        create the dto list.
        """
        clients = self.__client_service.get_all_clients()
        rentals = self.get_all_rentals()
        new_dict = {}
        for client in clients:
            new_dict[client.get_clientId()] = 0  # we initialize each to 0
        for rental in rentals:
            # we get the today date using datetime
            d = datetime.now().day
            m = datetime.now().month
            y = datetime.now().year
            today = Date(y, m, d)
            if rental.get_returnedDate() is None:
                # we can subtract 2 dates (in datetime) using the above line of code
                new_dict[rental.get_clientId()] += abs(today - rental.get_rentedDate()).days

        dtos = []
        for key, value in new_dict.items():
            client = self.__client_service.get_by_id(key)
            client_dto = ClientDto(client.get_name(), value)
            dtos.append(client_dto)
        return dtos

    def most_active_clients(self):
        """
        This function will return a list of dtos - Client Name and how many rental days each client has, sorted in
        a descending order.
        """
        dtos = self.__get_clients_dto()
        return sorted(dtos, reverse=True, key=operator.attrgetter('count'))

    def __get_late_rental_movies_dto(self):
        """
        Will return a list of dtos containing a movie name and how many days late is each one, using the same algoritm
        as the function above get_clients_dtos.
        """
        movies = self.__movie_service.get_all_movies()
        rentals = self.get_all_rentals()
        new_dict = {}
        for movie in movies:
            new_dict[movie.get_movieId()] = 0  # we initialize the values of the dict to 0
        for rental in rentals:
            d = datetime.now().day
            m = datetime.now().month
            y = datetime.now().year
            today = Date(y, m, d)
            if rental.get_returnedDate() is None and today > rental.get_dueDate():
                new_dict[rental.get_movieId()] = abs(today - rental.get_dueDate()).days
        dtos = []
        for key, value in new_dict.items():
            movie = self.__movie_service.get_by_id(key)
            if value > 0:
                movie_dto = MovieDto(movie.get_title(), value)
                dtos.append(movie_dto)
        return dtos

    def late_rentals(self):
        """
        Will return a list of dtos containing each movie title and how many days each movie is late in descending order.
        """
        dtos = self.__get_late_rental_movies_dto()
        return sorted(dtos, reverse=True, key=operator.attrgetter('count'))
