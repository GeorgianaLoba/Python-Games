from ro.ubb.movierental.domain.entities import Movie
from ro.ubb.movierental.service.undo.handlers import UndoHandler
from ro.ubb.movierental.service.undo.manager import UndoManager


class MovieService:
    def __init__(self, __repo, __valid):
        self.__repo = __repo
        self.__valid = __valid

    def create_movie (self, movieId, title, description, genre):
        """
        This function will create a movie object and then return it.
        """
        movie = Movie(movieId, title, description, genre)
        self.__valid.validate_movie(movie)
        return movie

    def add_movie(self, movieId, title, description, genre):
        """
        This function will add a movie to my list of movies.
        """
        self.__repo.add(self.create_movie(movieId, title, description, genre))
        UndoManager.register_operation(self, UndoHandler.ADD_MOVIE, movieId, title, description, genre)

    def get_all_movies(self):
        """
        Will return the list of movies.
        """
        return self.__repo.get_all()

    def get_by_id(self, id):
        """
        this function will return the object movie that has a given id
        """
        movies = self.get_all_movies()
        for movie in movies:
            if movie.get_movieId() == int(id):
                return movie

    def remove_movie(self, movie):
        """
        deleting a movie object from my list of movies
        """
        self.__repo.remove(movie)
        return [movie.get_movieId(), movie.get_title(), movie.get_description(), movie.get_genre()]

    def update_movie(self, movie):
        """
        is updating the given by id movie from my original list
        """
        self.__valid.validate_movie(movie)
        movies = self.get_all_movies()
        for m in movies:
            if m.get_movieId() == movie.get_movieId():
                UndoManager.register_operation(self, UndoHandler.UPDATE_MOVIE, m.get_movieId(), m.get_title(),
                                               m.get_description(), m.get_genre())
        self.__repo.update(movie)

    def search_movies_by_word(self, word):
        """
        this functions is searching every occurrence of a word inside my movies list;
        will search in title, description and genre;
        case-insensitive and partial string matching;
        find function will return the index of the first appearance of the given word or -1
        if it doesn't exist;
        lower function will make all characters lowercase in order to use find the given word
        """
        new_list = []
        movies = self.get_all_movies()
        for movie in movies:
            if movie.get_title().lower().find(word.lower()) is not -1:
                new_list.append(movie)
            elif movie.get_description().lower().find(word.lower()) is not -1:
                new_list.append(movie)
            elif movie.get_genre().lower().find(word.lower()) is not -1:
                new_list.append(movie)
        return new_list


