from ro.ubb.movierental.domain.entities import Client
from ro.ubb.movierental.service.undo.handlers import UndoHandler
from ro.ubb.movierental.service.undo.manager import UndoManager


class ClientService:
    def __init__(self, __repo, __valid):
        self.__repo = __repo
        self.__valid = __valid

    def create_client(self, clientId, name):
        """
        This function creates a client object and then returns it.
        """
        client = Client(clientId, name)
        self.__valid.validate_client(client)
        return client

    def add_client(self, clientId, name):
        """
        This function will add a client to my list of clients.
        """
        self.__repo.add(self.create_client(clientId, name))
        UndoManager.register_operation(self, UndoHandler.ADD_CLIENT, clientId, name)

    def get_all_clients(self):
        """
        Will return the list of clients.
        """
        return self.__repo.get_all()

    def get_by_id(self, id):
        clients = self.get_all_clients()
        for client in clients:
            if client.get_clientId() == int(id):
                return client

    def remove_client(self, client):
        """
        will remove a certain client from my list of clients
        """
        self.__repo.remove(client)
        return [client.get_clientId(), client.get_name()]

    def update_client(self, c):
        """
        Will update the client with the specified id
        """
        self.__valid.validate_client(c)
        clients = self.get_all_clients()
        for client in clients:
            if client.get_clientId() == int(c.get_clientId()):
                UndoManager.register_operation(self, UndoHandler.UPDATE_CLIENT, client.get_clientId(), client.get_name())
        self.__repo.update(c)

    def search_clients_by_word(self, word):
        """
        will search for every word occurrence in a certain list;
        case insensitive and partial string matching
        """
        new_list=[]
        clients = self.get_all_clients()
        for client in clients:
            if client.get_name().lower().find(word.lower()) is not -1:
                new_list.append(client)
        return new_list