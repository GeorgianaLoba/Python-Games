class UndoOperations:
    """
    This is my class of UndoOperations which has a source obj(in my case, either movie_service, client_service
    or rental_service), has a handler which basically points to the last operation made (for example, remove_movie)
    and also, has a number of args (such as movieId, title, description and genre) which is variable
    since, depending on the source obj, we have a specific number of variables(a client has 2, id and name, whereas
    movies have 4)
    """
    def __init__(self, source_obj, handler, args):
        self.__source_obj = source_obj
        self.__handler = handler
        self.__args = args

    def get_source_obj(self):
        return self.__source_obj

    def get_handler(self):
        return self.__handler

    def get_args(self):
        return self.__args

    def __str__(self) -> str:
        return "The {0} has {1} with {2}".format(self.get_source_obj(), self.get_handler(), self.get_args())


class UndoManager:
    __undo_operations = [] # this is the list that stores my LPO as objects of class UndoOperations

    @staticmethod
    def register_operation(source_obj, handler, *args):
        # undo_operations inserts an object of class UndoOperations, basically the LPO (which needs to be undo-ed)
        UndoManager.__undo_operations.append(UndoOperations(source_obj, handler, args))

    @staticmethod
    def undo():
        """
        This is the function that is basically doing the undo.
        """
        if len(UndoManager.__undo_operations) == 0:
            raise ValueError("Nothing to undo anymore.")
        undo_operation = UndoManager.__undo_operations.pop() # with .pop we get the last element of the list
        # The following line will call the specific handler(for example, REMOVE_MOVIE) and will do the undo
        undo_operation.get_handler()(undo_operation.get_source_obj(), *undo_operation.get_args())
