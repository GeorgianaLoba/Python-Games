from enum import Enum

from ro.ubb.movierental.service.redo.handlers import RedoHandler
from ro.ubb.movierental.service.redo.manager import RedoManager


def add_movie_undo_handler(movie_service, movieId, title, description, genre):
    """
    When we add a movie and then we want to do an undo, we basically want to remove that certain movie from the database,
    therefore we do so by simply calling the specific service function. Also, for the redo, we want to register the
    operation.
    """
    RedoManager.register_operation(movie_service, RedoHandler.REMOVE_MOVIE, movieId, title, description, genre)
    movie_service.remove_movie(movie_service.create_movie(movieId, title, description, genre))


def add_client_undo_handler(client_service, clientId, name):
    # used the same logic as in the add_movie function
    RedoManager.register_operation(client_service, RedoHandler.REMOVE_CLIENT, clientId, name)
    client_service.remove_client(client_service.create_client(clientId, name))


def add_rental_undo_handler(rental_service, rentalId, movieId, clientId, rentedDate, dueDate, returnedDate):
    # used the same logic as in the add_movie function
    RedoManager.register_operation(rental_service, RedoHandler.REMOVE_RENTAL, rentalId, movieId, clientId, rentedDate,
                                   dueDate, returnedDate)
    rental_service.remove_rental(rental_service.create_rental(rentalId, movieId, clientId, rentedDate, dueDate,
                                                              returnedDate))


def remove_movie_undo_handler(movie_service, movieId, title, description, genre, list, rental_service):
    """
    When we remove a certain movie(or client), we also remove all the afferent rentals of that movie/client. Therefore,
    when we undo the removing, we want to add the movie as well as add all the rentals. In the list variable, we basically
    have a list of rental objects with which we can work easily.
    """
    RedoManager.register_operation(movie_service, RedoHandler.ADD_MOVIE, movieId, title, description, genre, list, rental_service)
    movie_service.add_movie(movieId, title, description, genre)
    for rental in list:
        rental_service.add_rental(rental.get_rentalId(), rental.get_movieId(), rental.get_clientId(),
                                  rental.get_rentalId, rental.get_dueDate(), rental.get_returnedDate())


def remove_client_undo_handler(client_service, clientId, name, list, rental_service):
    # used the same logic as in the remove_movie function
    RedoManager.register_operation(client_service, RedoHandler.ADD_CLIENT, clientId, name, list, rental_service)
    client_service.add_client(clientId, name)
    for rental in list:
        rental_service.add_rental(rental.get_rentalId(), rental.get_movieId(), rental.get_clientId(),
                                  rental.get_rentalId, rental.get_dueDate(), rental.get_returnedDate())


def remove_rental_undo_handler(rental_service, rentalId, movieId, clientId, rentedDate, dueDate, returnedDate):
    RedoManager.register_operation(rental_service, RedoHandler.ADD_RENTAL, rentalId, movieId, clientId, rentedDate,
                                   dueDate, returnedDate)
    rental_service.add_rental(rentalId, movieId, clientId, rentedDate, dueDate, returnedDate)


def update_movie_undo_handler(movie_service, movieId, title, description, genre):
    """
     When I used the specific update function from the movie service, i was getting an error(unknown one). I fixed it
     by doing the update manually.
     """
    movies = movie_service.get_all_movies()
    for movie in movies:
        if movie.get_movieId() == int(movieId):
            RedoManager.register_operation(movie_service, RedoHandler.UPDATE_MOVIE, movie.get_movieId(), movie.get_title(),
                                           movie.get_description(), movie.get_genre())
            movie.set_title(title)
            movie.set_description(description)
            movie.set_genre(genre)
            break


def update_client_undo_handler(client_service, clientId, name):
    # used the same logic as in update_movie function
    clients = client_service.get_all_clients()
    for client in clients:
        if client.get_clientId() == int(clientId):
            RedoManager.register_operation(client_service, RedoHandler.UPDATE_CLIENT, client.get_clientId(), client.get_name())
            client.set_name(name)
            break


class UndoHandler (Enum):
    # these act as pointers and will call a specific function every time (as well as giving the functions the
    # corresponding parameters
    ADD_MOVIE = add_movie_undo_handler
    REMOVE_MOVIE = remove_movie_undo_handler
    UPDATE_MOVIE = update_movie_undo_handler
    ADD_CLIENT = add_client_undo_handler
    REMOVE_CLIENT = remove_client_undo_handler
    UPDATE_CLIENT = update_client_undo_handler
    ADD_RENTAL = add_rental_undo_handler
    REMOVE_RENTAL = remove_rental_undo_handler

