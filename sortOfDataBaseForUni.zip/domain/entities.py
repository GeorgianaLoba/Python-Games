class Movie:
    def __init__(self, movieId, title, description, genre):
        self.__movieId = movieId
        self.__title = title
        self.__description = description
        self.__genre = genre

    def get_movieId(self):
        return self.__movieId

    def get_title(self):
        return self.__title

    def get_description(self):
        return self.__description

    def get_genre(self):
        return self.__genre

    def set_title(self, title):
        self.__title = title

    def set_description(self, description):
        self.__description = description

    def set_genre(self, genre):
        self.__genre = genre

    def __str__(self) -> str:
        return "Movie Id: {0}, Title: {1}, Description: {2}, Genre: {3}".format(self.get_movieId(), self.get_title(),
                                                                                self.get_description(), self.get_genre())

    def __eq__(self, object):
        return self.__movieId == object.get_movieId()

    def __ne__(self, object):
        return not self.__movieId == object.get_movieId()


class Client:
    def __init__(self, clientId, name):
        self.__clientId = clientId
        self.__name = name

    def get_clientId(self):
        return self.__clientId

    def get_name(self):
        return self.__name

    def set_name(self, name):
        self.__name = name

    def __str__(self) -> str:
        return "Client Id: {0}, Client Name: {1}".format( self.get_clientId(), self.get_name() )

    def __eq__(self, object):
        return self.__clientId == object.get_clientId()

    def __ne__(self, object):
        return not self.__clientId == object.get_clientId


class Rental:
    def __init__(self, rentalId, movieId, clientId, rentedDate, dueDate, returnedDate=None):
        self.__rentalId = rentalId
        self.__movieId = movieId
        self.__clientID = clientId
        self.__rentedDate = rentedDate
        self.__dueDate = dueDate
        self.__returnedDate = returnedDate

    def get_rentalId(self):
        return self.__rentalId

    def get_movieId(self):
        return self.__movieId

    def get_clientId(self):
        return self.__clientID

    def get_rentedDate(self):
        return self.__rentedDate

    def get_dueDate(self):
        return self.__dueDate

    def get_returnedDate(self):
        return self.__returnedDate

    def __str__(self) -> str:
        return "Rental Id: {0}, Movie Id: {1}, Client Id: {2}, Rented Date: {3}, Due Date: {4}," \
               " Returned Date: {5}".format(self.get_rentalId(), self.get_movieId(), self.get_clientId(),
                                            self.get_rentedDate(), self.get_dueDate(), self.get_returnedDate() )

    def __eq__(self, object):
        return self.__rentalId == object.get_rentalId()

    def __ne__(self, object):
        return not self.__rentalId == object.get_rentalId




