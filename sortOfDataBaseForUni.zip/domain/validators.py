from ro.ubb.movierental.errors.errors import ValidationError


class MovieValidator:
    def __init__(self):
        pass

    def validate_movie(self, movie):
        errors=""
        if movie.get_movieId()<0:
            errors+="The id should be a positive number\n"
        if movie.get_title()=="":
            errors+="You must introduce a title name\n"
        if movie.get_description()=="":
            errors+="You must introduce a movie description\n"
        if movie.get_genre()=="":
            errors += "You must introduce a movie genre\n"
        if len(errors)>0:
            raise ValidationError(errors)


class ClientValidator:
    def __init__(self):
        pass

    def validate_client(self, client):
        errors=""
        if client.get_clientId()<0:
            errors+="The id should be a positive number\n"
        if client.get_name()=="":
            errors+="You must introduce a client name\n"
        if len(errors)>0:
            raise ValidationError(errors)


class RentalValidator:
    def __init__(self):
        pass

    def validate_rental(self, rental):
        errors = ""
        if rental.get_rentalId() < 0:
            errors += "The id should be a positive number\n"
        if len(errors) > 0:
            raise ValidationError(errors)