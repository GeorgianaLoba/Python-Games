class MovieDto:
    def __init__(self, movie_title, count):
        self.movie_title = movie_title
        self.count = count

    def get_movie_title(self):
        return self.movie_title

    def get_count(self):
        return self.count

    def __str__(self) -> str:
        return "Movie title: {0}, Count: {1}".format(self.get_movie_title(), self.get_count())


class ClientDto:
    def __init__(self, client_name, count):
        self.client_name = client_name
        self.count = count

    def get_client_name(self):
        return self.client_name

    def get_count(self):
        return self.count

    def __str__(self) -> str:
        return "Client Name: {0}, Number of movie rental days: {1}".format(self.get_client_name(), self.get_count())

