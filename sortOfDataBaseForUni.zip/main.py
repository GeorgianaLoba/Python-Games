from ro.ubb.movierental.domain.validators import MovieValidator, ClientValidator, RentalValidator
from ro.ubb.movierental.repository.clientbinaryrepo import ClientBinaryRepo
from ro.ubb.movierental.repository.clientrepo import ClientRepo
from ro.ubb.movierental.repository.moviebinaryrepo import MovieBinaryRepo
from ro.ubb.movierental.repository.movierepo import MovieRepo
from ro.ubb.movierental.repository.rentalbinaryrepo import RentalBinaryRepo
from ro.ubb.movierental.repository.rentalrepo import RentalRepo
from ro.ubb.movierental.repository.repository import Repository
from ro.ubb.movierental.service.clientservice import ClientService
from ro.ubb.movierental.service.movieservice import MovieService
from ro.ubb.movierental.service.rentalservice import RentalService
from ro.ubb.movierental.ui.console import Console

if __name__ == '__main__':
    movie_validator = MovieValidator()
    client_validator = ClientValidator()
    rental_validator = RentalValidator()
    try:
        file = open("settings.properties.txt", 'r')
        line = file.readline().strip().split('=')
        k = 0
        if line[1].strip() == 'inmemory':
            movie_repository = Repository()
            client_repository = Repository()
            rental_repository = Repository()
            k = 1
        elif line[1].strip() == 'textfiles':
            movie_repository = MovieRepo()
            client_repository = ClientRepo()
            rental_repository = RentalRepo()
        else:
            movie_repository = MovieBinaryRepo()
            client_repository = ClientBinaryRepo()
            rental_repository = RentalBinaryRepo()

        movie_service = MovieService(movie_repository, movie_validator)
        client_service = ClientService(client_repository, client_validator)
        rental_service = RentalService(rental_repository, movie_service, client_service, rental_validator)
        console = Console(movie_service, client_service, rental_service)
        if k == 1:
            console.generate_in_memory()
        console.run()
    except Exception as ex:
        print(ex)