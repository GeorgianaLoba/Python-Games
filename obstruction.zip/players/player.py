class Player:
    def __init__(self, name, board):
        self.__name = name
        self.board = board
